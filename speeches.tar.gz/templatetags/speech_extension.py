# -*- coding: utf-8 -*-

from collections import defaultdict
from heapq import nlargest
from operator import itemgetter
from django import template
import re
from django.utils.html import strip_tags
import json

register = template.Library()


@register.assignment_tag
def get_top_speakers(count=6):
    from speeches.models import Speech, Speaker
    from django.db.models import Count

    top_speakers_list = Speech.objects.values('speaker').annotate(count=Count('speaker')).order_by('speaker').order_by(
        '-count')[0:count]
    top_speakers = []
    for speaker in top_speakers_list:
        the_speaker = Speaker.objects.get(pk=speaker['speaker'])
        # setattr(the_speaker, 'count', speaker['count])
        the_speaker.count = speaker['count']
        top_speakers.append(the_speaker)
    return top_speakers


@register.assignment_tag
def get_common_words(count=20):
    from speeches.models import Speech

    r_punctuation = re.compile(r"[^\s\w0-9'’—-]", re.UNICODE)
    r_whitespace = re.compile(r'[\s—]+')
    STOPWORDS = frozenset([
        'i', 'me', 'my', 'myself', 'we', 'our', 'ours', 'ourselves', 'you', 'your',
    ])

    speeches = Speech.objects.all()

    word_counts = defaultdict(int)
    total_count = 0

    for speech in speeches:
        for word in r_whitespace.split(r_punctuation.sub(' ', strip_tags(speech.text).lower())):
            if word not in STOPWORDS and len(word) > 2:
                word_counts[word] += 1
                total_count += 1

    word_counts = {word: count for word, count in word_counts.items()}
    most_common_words = nlargest(50, word_counts.items(), key=itemgetter(1))
    return json.dumps(most_common_words)
